﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    public partial class AddFriendForm : Form {
        Ado ado = null;
        User user = null;
        User friend = null;
        Socket InfoSocket = null;
        public AddFriendForm(User user,Socket infoSocket) {
            InitializeComponent();
            this.MaximizeBox = false;
            this.user = user;
            this.InfoSocket = infoSocket;
            ado = new Ado();

            this.FormBorderStyle = FormBorderStyle.FixedDialog;
        }

        private void searchButton_Click(object sender, EventArgs e) {
            
            friend =ado.GetUserById(friendNum.Text);
            friendNameLabel.Text = "查找成功： "+friend.Name;
            if (friend.Name == null) {
                friendNameLabel.Text = "此人不存在";
            }
        }

        private void addButton_Click(object sender, EventArgs e) {
            //判断好友是否为null
            if (friend == null) {
                MessageBox.Show("请先查找到好友再点击添加按钮！");
                return;
            }
            //判断好友是否为空对象
            if (friend.Id == null) {
                MessageBox.Show("请先查找到好友再点击添加按钮！");
                return;
            }

            //判断好友是否为自己
            if (friend.Id == user.Id) {
                MessageBox.Show("您不能添加自己为好友！");
                return;
            }



            for (int i=20000;i<20200;i++) {
                if (i == ((IPEndPoint)InfoSocket.LocalEndPoint).Port) {
                    continue;
                }
                try {
                    EndPoint point = new IPEndPoint(IPAddress.Parse(friend.Ip), i);

                    InfoSocket.SendTo(Encoding.UTF8.GetBytes("请求成为好友"+user.Id), point);
                }catch { }
            }

            MessageBox.Show("你的请求发送成功，请耐心等待等待对方回应！");
            

        }
    }
}
