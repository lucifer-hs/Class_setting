﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Collections;

namespace 溜溜 {
    class Ado {

        //public static void Main() {
        //    Ado ado = new Ado();
        //    //MessageBox.Show(ado.GenerateId());
           
        //    MessageBox.Show("测试成功！");


        //}
        //使指定id的两个人成为好友
        public void BecomeFriends(string id1,string id2) {
            if (id1.Equals(id2)) {
                return;
            }
            ArrayList friendsList= this.GetFriendsById(id1);

            foreach(User friend in friendsList) {
                
                if (id2.Equals(friend.Id)) {
                    MessageBox.Show("你们已经是好友了，不用重新添加！");
                    return;
                }
            }
           
            string sql = "insert into friends values('" +id1+ "','" + id2+"')";
            this.ExecuteNonQuery(sql);
        }

        //通过id删除用户
        public void DeleteUserById(string id) {
            
            string sql = "DELETE FROM user_info WHERE id = '"+id+"'";
            ExecuteNonQuery(sql);
        }

        //生成一个可用的id
        public String GenerateId() {
            string id = null;
            
            for (int i=100000000;i<999999999;i++) {
                
                string sql = "SELECT id FROM user_info WHERE id='" + i + "'";
                id = (string)ExecuteQuery(sql);
                if (id==null) {
                    id = i+"";
                    
                    break;
                }
            }
            
            return id;
        }

        //通过id获取好友
        public ArrayList GetFriendsById(String id) {
            ArrayList friendsList = new ArrayList();
            try {

                String sql1 = "SELECT id1 FROM friends WHERE id2='" + id + "'";
                String sql2 = "SELECT id2 FROM friends WHERE id1='" + id + "'";
                SqlConnection conn = Ado.GetConnection();
                using (SqlCommand cmd = new SqlCommand(sql1, conn)) {
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read()) {

                        friendsList.Add(GetUserById((string)reader[0]));
                    }
                    reader.Close();
                }
                conn.Close();

                conn = Ado.GetConnection();
                using (SqlCommand cmd = new SqlCommand(sql2, conn)) {

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    
                    while (reader.Read()) {
                        friendsList.Add(GetUserById((string)reader[0]));

                    }
                    reader.Close();
                }
                conn.Close();



            } catch (Exception e) {
                //MessageBox.Show(e.Message);
                //MessageBox.Show(e.GetType().ToString());
                //MessageBox.Show(e.StackTrace);
            }
            return friendsList;
        }
        //通过ip和端口获得User对象
        internal User GetUserByIpAndPort(string ip, object port) {
            User user = new User();
            string sql = "SELECT * FROM user_info WHERE ip='" + ip + "' AND port='"+port+"'";
            using (SqlConnection conn = Ado.GetConnection()) {
                using (SqlCommand cmd = new SqlCommand(sql, conn)) {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read()) {
                        user.Id = (string)reader["id"];
                        user.Password = (string)reader["password"];
                        user.Ip = (string)reader["ip"];
                        user.Port = (string)reader["port"];
                        user.Name = (string)reader["name"];
                        user.PhoneNum = (string)reader["phoneNum"];
                        user.Email = (string)reader["email"];
                        user.Occupation = (string)reader["occupation"];
                        user.OtherInfo = (string)reader["otherInfo"];
                        

                    }
                }
            }

            return user;
        }

        //通过id获得User对象
        public User GetUserById(string id) {
            User user = new User();
            string sql = "select * from user_info where id='" + id + "'";
            using (SqlConnection conn = Ado.GetConnection()) {
                using (SqlCommand cmd = new SqlCommand(sql, conn)) {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read()) {
                        user.Id = (string)reader["id"];
                        user.Password = (string)reader["password"];
                        user.Ip = (string)reader["ip"];
                        user.Port = (string)reader["port"];
                        user.Name = (string)reader["name"];
                        user.PhoneNum = (string)reader["phoneNum"];
                        user.Email = (string)reader["email"];
                        user.Occupation = (string)reader["occupation"];
                        user.OtherInfo = (string)reader["otherInfo"];


                    }
                }
            }

            return user;
        }
        //插入一个新用户
        public void InsertUser(User user) {
            string sql = "insert into user_info values('" + user.Id + "','" + user.Password + "','" + user.Ip + "','" + user.Port + "','" + user.Name + "','" + user.PhoneNum + "','" + user.Email + "','" + user.Occupation + "','" + user.OtherInfo + "')";
            this.ExecuteNonQuery(sql);
        }
        //更新用户信息
        public void UpdateUser(User user) {
            string sql = "UPDATE user_info SET id = '" + user.Id + "',password = '" + user.Password + "',ip = '" + user.Ip + "',port = '" + user.Port + "',name = '" + user.Name + "',phoneNum = '" + user.PhoneNum + "',email = '" + user.Email + "',occupation = '" + user.Occupation + "',otherInfo = '" + user.OtherInfo + "' WHERE id = '" + user.Id + "' ";
            //MessageBox.Show(sql);
            this.ExecuteNonQuery(sql);
        }
        //验证登录帐号密码是否正确
        public bool VerifyLogin(string id, string password) {
            string sql = "select password from user_info where id='" + id + "'";
            try {
                //帐号不存在会抛异常
                string realPassword = (string)this.ExecuteQuery(sql);
                if (realPassword.Equals(password)) {
                    return true;
                }
            } catch (Exception e) {
                //MessageBox.Show(e.Message);
                //MessageBox.Show(e.GetType().ToString());
                //MessageBox.Show(e.StackTrace);
            }

            return false;
        }
        //获得数据库服务器的连接对象
        public static SqlConnection GetConnection() {
            //if (conn == null) {
            //    conn= new SqlConnection(@"server = 192.168.1.119;database = LiuLiu;uid =loubth ;pwd=973927314");
            //}
            return new SqlConnection(@"server = 192.168.1.112;database = LiuLiu;uid =loubth ;pwd=973927314");
        }
        //执行废查询语句
        public void ExecuteNonQuery(string sql) {
            using (SqlConnection conn = Ado.GetConnection()) {
                using (SqlCommand cmd = new SqlCommand(sql, conn)) {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
        //执行查询语句获得一个结果
        public object ExecuteQuery(string sql) {
            object obj;
            using (SqlConnection conn = Ado.GetConnection()) {
                using (SqlCommand cmd = new SqlCommand(sql, conn)) {
                    conn.Open();
                    obj = cmd.ExecuteScalar();
                }
            }
            return obj;
        }




    }
}
