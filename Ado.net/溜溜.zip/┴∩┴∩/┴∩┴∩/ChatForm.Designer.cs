﻿namespace 溜溜 {
    partial class ChatForm {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChatForm));
            this.SendContentTextBox = new System.Windows.Forms.TextBox();
            this.CloseButton = new System.Windows.Forms.Button();
            this.ChatRecordRichTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SendButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SendContentTextBox
            // 
            this.SendContentTextBox.BackColor = System.Drawing.Color.White;
            this.SendContentTextBox.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SendContentTextBox.Location = new System.Drawing.Point(0, 436);
            this.SendContentTextBox.Multiline = true;
            this.SendContentTextBox.Name = "SendContentTextBox";
            this.SendContentTextBox.Size = new System.Drawing.Size(553, 122);
            this.SendContentTextBox.TabIndex = 4;
            this.SendContentTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SendContentTextBox_KeyDown);
            this.SendContentTextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.SendContentTextBox_KeyUp);
            // 
            // CloseButton
            // 
            this.CloseButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.CloseButton.Location = new System.Drawing.Point(325, 534);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(112, 23);
            this.CloseButton.TabIndex = 6;
            this.CloseButton.Text = "关闭(Ctrl+W)";
            this.CloseButton.UseVisualStyleBackColor = false;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // ChatRecordRichTextBox1
            // 
            this.ChatRecordRichTextBox1.BackColor = System.Drawing.Color.White;
            this.ChatRecordRichTextBox1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ChatRecordRichTextBox1.ForeColor = System.Drawing.Color.Blue;
            this.ChatRecordRichTextBox1.HideSelection = false;
            this.ChatRecordRichTextBox1.Location = new System.Drawing.Point(0, 12);
            this.ChatRecordRichTextBox1.Name = "ChatRecordRichTextBox1";
            this.ChatRecordRichTextBox1.ReadOnly = true;
            this.ChatRecordRichTextBox1.Size = new System.Drawing.Size(553, 423);
            this.ChatRecordRichTextBox1.TabIndex = 12;
            this.ChatRecordRichTextBox1.Text = "";
            // 
            // SendButton
            // 
            this.SendButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.SendButton.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SendButton.Location = new System.Drawing.Point(437, 534);
            this.SendButton.Name = "SendButton";
            this.SendButton.Size = new System.Drawing.Size(112, 23);
            this.SendButton.TabIndex = 7;
            this.SendButton.Text = "发送(Ctrl+Enter)";
            this.SendButton.UseVisualStyleBackColor = false;
            this.SendButton.Click += new System.EventHandler(this.SendButton_Click);
            // 
            // ChatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(554, 559);
            this.Controls.Add(this.ChatRecordRichTextBox1);
            this.Controls.Add(this.SendButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.SendContentTextBox);
            this.Name = "ChatForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChatForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox SendContentTextBox;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.RichTextBox ChatRecordRichTextBox1;
        private System.Windows.Forms.Button SendButton;
    }
}

