﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    public partial class ChatForm : Form {
        User Friend;
        Socket ServerSocket;

        string MyIp;
        string MyPort;
        string FriendIp;
        string FriendPort;
        
        
        

        public ChatForm(Socket serverSocket,User friend) {
           

            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Friend = friend;
            this.Text = "                                                        与“" + friend.Name+ "”聊天";

            ServerSocket = serverSocket;
            

            MyIp = this.GetMyIP();
            //MyIpTextBox.Text = MyIp;
            
            MyPort = ((IPEndPoint)ServerSocket.LocalEndPoint).Port.ToString();            
            //MyPortTextBox.Text = MyPort;
            
            FriendIp = friend.Ip;
            //FriendIpTextBox.Text = FriendIp;

            FriendPort = friend.Port;
            //FriendPortTextBox.Text = FriendPort;



            SendButton.FlatStyle = FlatStyle.Flat;//样式
            //SendButton.BackColor = Color.Transparent;//去背景
            SendButton.FlatAppearance.BorderSize = 0;//去边线
            SendButton.FlatAppearance.MouseOverBackColor = Color.Transparent;//鼠标经过
            SendButton.FlatAppearance.MouseDownBackColor = Color.Gray;//鼠标按下

            CloseButton.FlatStyle = FlatStyle.Flat;//样式
            //SendButton.BackColor = Color.Transparent;//去背景
            CloseButton.FlatAppearance.BorderSize = 0;//去边线
            CloseButton.FlatAppearance.MouseOverBackColor = Color.Transparent;//鼠标经过
            CloseButton.FlatAppearance.MouseDownBackColor = Color.Gray;//鼠标按下




            Thread waitThread = new Thread(new ThreadStart(WaitReceiveContent));
            waitThread.IsBackground = true;
            waitThread.Start();

            //防止一台机子上演示 出现 好友不在线但因为ip和端口相同 自己和自己对话的bug
            if (MyIp==FriendIp&&MyPort==FriendPort) {
                int num=int.Parse(FriendPort);
                FriendPort = num + 1 + "";
                //FriendPortTextBox.Text = FriendPort;
            }


           
        }

    

        private void WaitReceiveContent() {
            try {
                while (true) {
                    EndPoint point = new IPEndPoint(IPAddress.Parse(FriendIp), int.Parse(FriendPort));//用来保存发送方的ip和端口号
                    byte[] buffer = new byte[1024];
                    int length = ServerSocket.ReceiveFrom(buffer, ref point);//接收数据报

                    //MessageBox.Show("收到" + Encoding.UTF8.GetString(buffer));
                    if (Encoding.UTF8.GetString(buffer).Equals("")) {
                        
                        continue;
                    }

                    ChatRecordRichTextBox1.SelectionColor = Color.Black;
                    ChatRecordRichTextBox1.AppendText("\n" + "☆☆☆☆");
                    
                    ChatRecordRichTextBox1.SelectionColor = Color.Gray;

                    if (Friend.Name.Length > 7) {
                        ChatRecordRichTextBox1.AppendText(Friend.Name.Substring(0, 7) + "...");
                    } else {
                        ChatRecordRichTextBox1.AppendText(Friend.Name);
                    }
                    
                    ChatRecordRichTextBox1.SelectionColor = Color.Black;
                    ChatRecordRichTextBox1.AppendText("☆☆☆☆" + "   ");
                    ChatRecordRichTextBox1.SelectionColor = Color.LightGray;
                    ChatRecordRichTextBox1.AppendText(DateTime.Now.ToLocalTime().ToString());

                    ChatRecordRichTextBox1.SelectionColor = Color.LimeGreen;
                    ChatRecordRichTextBox1.AppendText("\n" + Encoding.UTF8.GetString(buffer, 0, length));
                    
                }

            } catch (Exception e) {
                //MessageBox.Show(Friend.Name+"想要和你联系");
                //this.Close();
                //MessageBox.Show(e.Message);
                //MessageBox.Show(e.GetType().ToString());
                //MessageBox.Show(e.StackTrace);
            }

        }

        
    
        private void SendContent(string sendContent) {
            //MessageBox.Show("发送...");
            if (sendContent.Equals("")) {
                return;
            }
            byte[] send = Encoding.UTF8.GetBytes(sendContent);
            ChatRecordRichTextBox1.SelectionColor = Color.Black;
            ChatRecordRichTextBox1.AppendText("\n" + "★★★★★我★★★★★        " );
            ChatRecordRichTextBox1.SelectionColor = Color.LightGray;
            ChatRecordRichTextBox1.AppendText(DateTime.Now.ToLocalTime().ToString());
            ChatRecordRichTextBox1.SelectionColor =  Color.RoyalBlue;
            ChatRecordRichTextBox1.AppendText("\n" + sendContent);

            try {

                EndPoint point = new IPEndPoint(IPAddress.Parse(FriendIp), int.Parse(FriendPort));
                 
                ServerSocket.SendTo(Encoding.UTF8.GetBytes(sendContent), point);
                
            } catch (Exception e) {
                MessageBox.Show("好友不在线哦，换个时间联系吧！");
                //MessageBox.Show(e.Message);
                //MessageBox.Show(e.GetType().ToString());
                //MessageBox.Show(e.StackTrace);
                //this.Close();
            }

        }


        //得到本机的主机名
        private String GetMyIP() {
            string strHostName = Dns.GetHostName();
            IPHostEntry ipEntry = Dns.GetHostByName(strHostName);
            return ipEntry.AddressList[0].ToString(); //假设本地主机为单网卡
        }


        private void label1_Click(object sender, EventArgs e) {

        }

        private void CloseButton_Click(object sender, EventArgs e) {
            //Environment.Exit(0);
            this.Hide();
            this.Close();

        }

        private void SendButton_Click(object sender, EventArgs e) {

            if (SendContentTextBox.Text.Equals("")) {
                MessageBox.Show("发送内容不能为空！");                
                SendContentTextBox.Clear();                
                return;
            }

            SendContent(SendContentTextBox.Text);
            SendContentTextBox.Clear();
            SendContentTextBox.Focus();



        }

        private void MyIpTextBox_TextChanged(object sender, EventArgs e) {
           // MyIp = MyIpTextBox.Text;

        }

        private void MyPortTextBox_TextChanged(object sender, EventArgs e) {
          //  MyPort = MyPortTextBox.Text;

        }

        private void FriendIpTextBox_TextChanged(object sender, EventArgs e) {
          //  FriendIp = FriendIpTextBox.Text;

        }

        private void FriendPortTextBox_TextChanged(object sender, EventArgs e) {
           // FriendPort = FriendPortTextBox.Text;

        }

        private void SendContentTextBox_KeyUp(object sender, KeyEventArgs e) {
            /*经检测如果将清空（Clear）函数绑定在KeyDown事件中会导入输入框有一个空格所以将它绑定到了KeyUp事件
             *但是只绑定到KeyUp上又偶尔会清空不上 所以就都绑定了一下
            */
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.Enter) {
                SendContentTextBox.Clear();
            }
        }

        private void SendContentTextBox_KeyDown(object sender, KeyEventArgs e) {
            //给发送内容的文本框绑定组合键ctrl+enter发送消息
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.Enter) {
                SendButton_Click(null,null);
            }

            //给发送内容的文本框绑定组合键ctrl+w关闭窗口
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.W) {
                CloseButton_Click(null,null);
            }
            
        }

      
    }
}
