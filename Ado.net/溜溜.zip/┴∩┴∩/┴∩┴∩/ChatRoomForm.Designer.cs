﻿namespace 溜溜 {
    partial class ChatRoomForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.ChatRecordRichTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SendButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.SendContentTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ChatRecordRichTextBox1
            // 
            this.ChatRecordRichTextBox1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ChatRecordRichTextBox1.ForeColor = System.Drawing.Color.Blue;
            this.ChatRecordRichTextBox1.HideSelection = false;
            this.ChatRecordRichTextBox1.Location = new System.Drawing.Point(107, 60);
            this.ChatRecordRichTextBox1.Name = "ChatRecordRichTextBox1";
            this.ChatRecordRichTextBox1.ReadOnly = true;
            this.ChatRecordRichTextBox1.Size = new System.Drawing.Size(438, 322);
            this.ChatRecordRichTextBox1.TabIndex = 16;
            this.ChatRecordRichTextBox1.Text = "";
            // 
            // SendButton
            // 
            this.SendButton.Location = new System.Drawing.Point(433, 507);
            this.SendButton.Name = "SendButton";
            this.SendButton.Size = new System.Drawing.Size(112, 23);
            this.SendButton.TabIndex = 15;
            this.SendButton.Text = "发送(Ctrl+Enter)";
            this.SendButton.UseVisualStyleBackColor = true;
            // 
            // CloseButton
            // 
            this.CloseButton.Location = new System.Drawing.Point(315, 507);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(112, 23);
            this.CloseButton.TabIndex = 14;
            this.CloseButton.Text = "关闭(Ctrl+W)";
            this.CloseButton.UseVisualStyleBackColor = true;
            // 
            // SendContentTextBox
            // 
            this.SendContentTextBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SendContentTextBox.Location = new System.Drawing.Point(107, 388);
            this.SendContentTextBox.Multiline = true;
            this.SendContentTextBox.Name = "SendContentTextBox";
            this.SendContentTextBox.Size = new System.Drawing.Size(438, 103);
            this.SendContentTextBox.TabIndex = 13;
            // 
            // ChatRoomForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 591);
            this.Controls.Add(this.ChatRecordRichTextBox1);
            this.Controls.Add(this.SendButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.SendContentTextBox);
            this.Name = "ChatRoomForm";
            this.Text = "ChatRoomForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox ChatRecordRichTextBox1;
        private System.Windows.Forms.Button SendButton;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.TextBox SendContentTextBox;
    }
}