﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    public partial class ChatRoomForm : Form {
        public ChatRoomForm() {
            InitializeComponent();
            this.MaximizeBox = false;
        }
    }
}
