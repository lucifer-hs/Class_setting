﻿namespace 溜溜 {
    partial class LoginForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.SignIn = new System.Windows.Forms.Button();
            this.AccountNumber = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.SignUpLinkLabel = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // SignIn
            // 
            this.SignIn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SignIn.BackgroundImage")));
            this.SignIn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SignIn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SignIn.Location = new System.Drawing.Point(125, 295);
            this.SignIn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SignIn.Name = "SignIn";
            this.SignIn.Size = new System.Drawing.Size(320, 49);
            this.SignIn.TabIndex = 0;
            this.SignIn.Text = "登录";
            this.SignIn.UseVisualStyleBackColor = true;
            this.SignIn.Click += new System.EventHandler(this.SignIn_Click);
            // 
            // AccountNumber
            // 
            this.AccountNumber.Font = new System.Drawing.Font("楷体", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AccountNumber.Location = new System.Drawing.Point(125, 159);
            this.AccountNumber.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AccountNumber.MaxLength = 9;
            this.AccountNumber.Name = "AccountNumber";
            this.AccountNumber.Size = new System.Drawing.Size(319, 42);
            this.AccountNumber.TabIndex = 1;
            this.AccountNumber.TextChanged += new System.EventHandler(this.AccountNumber_TextChanged);
            this.AccountNumber.Enter += new System.EventHandler(this.AccountNumber_Enter);
            this.AccountNumber.Leave += new System.EventHandler(this.AccountNumber_Leave);
            // 
            // Password
            // 
            this.Password.Font = new System.Drawing.Font("楷体", 18F, System.Drawing.FontStyle.Bold);
            this.Password.Location = new System.Drawing.Point(125, 210);
            this.Password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Password.MaxLength = 16;
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(319, 42);
            this.Password.TabIndex = 2;
            this.Password.Enter += new System.EventHandler(this.Password_Enter);
            this.Password.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Password_KeyDown);
            this.Password.Leave += new System.EventHandler(this.Password_Leave);
            // 
            // SignUpLinkLabel
            // 
            this.SignUpLinkLabel.ActiveLinkColor = System.Drawing.Color.DimGray;
            this.SignUpLinkLabel.AutoSize = true;
            this.SignUpLinkLabel.BackColor = System.Drawing.Color.Transparent;
            this.SignUpLinkLabel.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SignUpLinkLabel.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.SignUpLinkLabel.LinkColor = System.Drawing.Color.Gray;
            this.SignUpLinkLabel.Location = new System.Drawing.Point(3, 328);
            this.SignUpLinkLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SignUpLinkLabel.Name = "SignUpLinkLabel";
            this.SignUpLinkLabel.Size = new System.Drawing.Size(49, 20);
            this.SignUpLinkLabel.TabIndex = 3;
            this.SignUpLinkLabel.TabStop = true;
            this.SignUpLinkLabel.Text = "注册";
            this.SignUpLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SignUpLinkLabel_LinkClicked);
            this.SignUpLinkLabel.MouseLeave += new System.EventHandler(this.SignUpLinkLabel_MouseLeave);
            this.SignUpLinkLabel.MouseHover += new System.EventHandler(this.SignUpLinkLabel_MouseHover);
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(549, 359);
            this.Controls.Add(this.SignUpLinkLabel);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.AccountNumber);
            this.Controls.Add(this.SignIn);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LoginForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoginForm_FormClosed);
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SignIn;
        private System.Windows.Forms.TextBox AccountNumber;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.LinkLabel SignUpLinkLabel;
    }
}