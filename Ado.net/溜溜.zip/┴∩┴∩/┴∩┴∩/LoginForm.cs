﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    public partial class LoginForm : Form {
        public LoginForm() {
            InitializeComponent();
            this.Text = "溜溜";
            this.MaximizeBox = false;
            AccountNumber.Text = "帐号";
            AccountNumber.ForeColor = Color.LightGray;
            
            Password.Text = "密码";
            Password.ForeColor = Color.LightGray;
            //禁止调整窗口大小            
            this.FormBorderStyle = FormBorderStyle.FixedDialog;


        }

        private void SignIn_Click(object sender, EventArgs e) {
            Ado ado = new Ado();
            bool isExist=ado.VerifyLogin(AccountNumber.Text, Password.Text);
            if (isExist) {
                User user=ado.GetUserById(AccountNumber.Text);
                user.Ip = this.GetMyIP();
                Socket ServerSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);//使用指定的地址簇协议、套接字类型和通信协议
                for (int i = 1997; i < 65536; i++) {

                    try {
                        IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(user.Ip), i);
                        ServerSocket.Bind(endPoint);
                        //ServerSocket.Listen(30);
                        
                        user.Port = i + "";
                        //MessageBox.Show(i + "" + "号端口占用成功！");
                        break;
                    } catch (Exception ee) {
                        //MessageBox.Show(ee.Message);
                        //MessageBox.Show(ee.GetType().ToString());
                        //MessageBox.Show(ee.StackTrace);
                    }
                }

                ado.UpdateUser(user);   //更新一下数据库中的ip和端口
                //WindowsManage.mainWindow = new MainForm(ServerSocket, user);
                //this.Visible = false;
                //WindowsManage.mainWindow.Visible = true;

                new MainForm(ServerSocket, user).Show();
                this.Visible = false;
            } else {
                MessageBox.Show("帐号或密码输入错误！");
            }
        }

        private String GetMyIP() {
            string strHostName = Dns.GetHostName();
            IPHostEntry ipEntry = Dns.GetHostByName(strHostName);
            return ipEntry.AddressList[0].ToString(); //假设本地主机为单网卡
        }

        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e) {
            this.Hide();
            Environment.Exit(0);
        }

        

       

        private void Password_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyCode == Keys.Enter) {
                SignIn_Click(null,null);
            }
        }

        private void SignUpLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            new SignUpForm().Show();
        }

        private void AccountNumber_Enter(object sender, EventArgs e) {
            if (AccountNumber.Text.Equals("帐号")) {
                AccountNumber.Text = "";
            }
            AccountNumber.ForeColor = Color.Black;
        }

        private void AccountNumber_Leave(object sender, EventArgs e) {
            if (AccountNumber.Text.Equals("")) {
                AccountNumber.Text = "帐号";
                AccountNumber.ForeColor = Color.LightGray;
            }
            
        }

        private void Password_Enter(object sender, EventArgs e) {
            if (Password.Text.Equals("密码")) {
                Password.Text = "";
            }
            Password.ForeColor = Color.Black;
            Password.PasswordChar = '●';
        }

        private void Password_Leave(object sender, EventArgs e) {
            if (Password.Text.Equals("")) {
                Password.ForeColor = Color.LightGray;
                Password.PasswordChar = '\0';
                Password.Text = "密码";
            }
            
            
        }

        private void SignUpLinkLabel_MouseHover(object sender, EventArgs e) {
            SignUpLinkLabel.LinkColor = Color.LightBlue;
        }

        private void SignUpLinkLabel_MouseLeave(object sender, EventArgs e) {
            SignUpLinkLabel.LinkColor = Color.Gray;
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void AccountNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
