﻿namespace 溜溜 {
    partial class MainForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("我的好友");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.UserNameLabel = new System.Windows.Forms.Label();
            this.FriendsTreeView = new System.Windows.Forms.TreeView();
            this.AddFriendsButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.UserNameLabel.Font = new System.Drawing.Font("华文行楷", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UserNameLabel.ForeColor = System.Drawing.Color.DimGray;
            this.UserNameLabel.Location = new System.Drawing.Point(-1, 33);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(273, 53);
            this.UserNameLabel.TabIndex = 0;
            this.UserNameLabel.Text = "您还没有用户名";
            this.UserNameLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // FriendsTreeView
            // 
            this.FriendsTreeView.BackColor = System.Drawing.Color.White;
            this.FriendsTreeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FriendsTreeView.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FriendsTreeView.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.FriendsTreeView.Location = new System.Drawing.Point(-1, 100);
            this.FriendsTreeView.Name = "FriendsTreeView";
            treeNode1.BackColor = System.Drawing.Color.Transparent;
            treeNode1.Name = "MyFriendsNode";
            treeNode1.Text = "我的好友";
            this.FriendsTreeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.FriendsTreeView.Size = new System.Drawing.Size(300, 379);
            this.FriendsTreeView.TabIndex = 1;
            this.FriendsTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.FriendsTreeView_AfterSelect);
            this.FriendsTreeView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.FriendsTreeView_MouseDoubleClick);
            // 
            // AddFriendsButton
            // 
            this.AddFriendsButton.BackColor = System.Drawing.Color.White;
            this.AddFriendsButton.Font = new System.Drawing.Font("华文彩云", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AddFriendsButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.AddFriendsButton.Location = new System.Drawing.Point(174, 485);
            this.AddFriendsButton.Name = "AddFriendsButton";
            this.AddFriendsButton.Size = new System.Drawing.Size(94, 30);
            this.AddFriendsButton.TabIndex = 2;
            this.AddFriendsButton.Text = "添加好友";
            this.AddFriendsButton.UseVisualStyleBackColor = false;
            this.AddFriendsButton.Click += new System.EventHandler(this.AddFriendsButton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("华文彩云", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(12, 485);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 30);
            this.button1.TabIndex = 3;
            this.button1.Text = "修改信息";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(280, 520);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.AddFriendsButton);
            this.Controls.Add(this.UserNameLabel);
            this.Controls.Add(this.FriendsTreeView);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label UserNameLabel;
        private System.Windows.Forms.TreeView FriendsTreeView;
        private System.Windows.Forms.Button AddFriendsButton;
        private System.Windows.Forms.Button button1;
    }
}