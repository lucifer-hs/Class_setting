﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    public partial class MainForm : Form {
        Ado ado = new Ado();
        Socket ServerSocket = null;
        Socket InfoSocket = null;
        User user = null;
        ArrayList FriendsNodes = new ArrayList();

        public MainForm(Socket ServerSocket, User user) {

            this.ServerSocket = ServerSocket;
            this.user = user;
            InitializeComponent();

            button1.FlatStyle = FlatStyle.Flat;//样式
            button1.BackColor = Color.Transparent;//去背景
            button1.FlatAppearance.BorderSize = 0;//去边线
            button1.FlatAppearance.MouseOverBackColor = Color.Transparent;//鼠标经过
            button1.FlatAppearance.MouseDownBackColor = Color.White;//鼠标按下

            AddFriendsButton.FlatStyle = FlatStyle.Flat;//样式
            AddFriendsButton.BackColor = Color.Transparent;//去背景
            AddFriendsButton.FlatAppearance.BorderSize = 0;//去边线
            AddFriendsButton.FlatAppearance.MouseOverBackColor = Color.Transparent;//鼠标经过
            AddFriendsButton.FlatAppearance.MouseDownBackColor = Color.White;//鼠标按下


            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.Text = "溜溜";
            Init();

            Thread waitThread = new Thread(new ThreadStart(Wait));
            waitThread.IsBackground = true;
            waitThread.Start();

        }

        private void Init() {
            
            //初始化昵称
            if (user.Name != null) {
                if (user.Name.Length > 7) {
                    UserNameLabel.Text = user.Name.Substring(0, 7) + "...";
                } else {
                    UserNameLabel.Text = user.Name;
                }
            }

            //初始化好友列表
            ArrayList friends = ado.GetFriendsById(user.Id);
            FriendsTreeView.Nodes["MyFriendsNode"].Nodes.Clear();
            FriendsNodes.Clear();
            foreach (User friend in friends) {
                TreeNode friendNode = new TreeNode(friend.Name+"("+friend.Id + ")");
                FriendsNodes.Add(friendNode);
                FriendsTreeView.Nodes["MyFriendsNode"].Nodes.Add(friendNode);
            }




        }

       

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e) {
            this.Hide();
            Environment.Exit(0);
        }
        
        private void FriendsTreeView_MouseDoubleClick(object sender, MouseEventArgs e) {
            if (FriendsTreeView.SelectedNode.Text.Equals("我的好友")) {
                return;
            }
            string SelectedNodeString = FriendsTreeView.SelectedNode.Text;
            string friendId = SelectedNodeString.Substring(SelectedNodeString.IndexOf('(')+1).Replace(")", "");
            
            User friend = ado.GetUserById(friendId);

            for (int i = 20000; i < 20200; i++) {
                if (i == ((IPEndPoint)InfoSocket.LocalEndPoint).Port) {
                    continue;
                }
                try {
                    EndPoint point = new IPEndPoint(IPAddress.Parse(friend.Ip), i);

                    InfoSocket.SendTo(Encoding.UTF8.GetBytes(user.Id+ "请求通信"), point);
                } catch(Exception ee) {
                    //MessageBox.Show(ee.Message);
                    //MessageBox.Show(ee.GetType().ToString());
                    //MessageBox.Show(ee.StackTrace);
                }
            }


           

            ChatForm friendChatForm = new ChatForm(ServerSocket,friend);
            //MessageBox.Show(friend.ToString());
            friendChatForm.Show();
            // Application.Run(friendChatForm);

        }

        private void AddFriendsButton_Click(object sender, EventArgs e) {
            new AddFriendForm(user,InfoSocket).Show();
        }

        private void button1_Click(object sender, EventArgs e) {
            new ModifyInfoForm(user).Show();
        }

        //监听加好友等请求
        public void Wait() {
            try {
                //先绑定一个端口用来通信
                InfoSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);//使用指定的地址簇协议、套接字类型和通信协议

                for (int i = 20000; i < 65536; i++) {

                    try {
                        IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(user.Ip), i);
                        InfoSocket.Bind(endPoint);
                        //ServerSocket.Listen(30);


                        //MessageBox.Show(i + "" + "号端口占用成功！");
                        break;
                    } catch (Exception ee) {
                        //MessageBox.Show(ee.Message);
                        //MessageBox.Show(ee.GetType().ToString());
                        //MessageBox.Show(ee.StackTrace);
                    }
                }



                while (true) {
                    for (int i = 20000; i < 20200; i++) {

                        if (i == ((IPEndPoint)InfoSocket.LocalEndPoint).Port) {
                            continue;
                        }
                        try {
                            EndPoint point = new IPEndPoint(IPAddress.Any, i);//用来保存发送方的ip和端口号
                            byte[] buffer = new byte[1024];

                            if (InfoSocket.Available > 0) {

                                int length = InfoSocket.ReceiveFrom(buffer, ref point);//接收数据报

                                string receiveString = Encoding.UTF8.GetString(buffer).Replace("\0", "");
                               
                                if (receiveString.Contains("请求成为好友")) {
                                    #region
                                    string friendId = receiveString.Replace("请求成为好友", "");
                                    if (user.Id.Equals(friendId)) {
                                        continue;
                                    }
                                    DialogResult result = MessageBox.Show(friendId + " 请求与您成为好友，是否同意？", "好友请求", MessageBoxButtons.OKCancel);
                                    if (result.ToString().Equals("OK")) {

                                        ado.BecomeFriends(user.Id, friendId);
                                        MessageBox.Show("您已经与溜溜号为" + friendId + "的用户成为好友！");


                                       

                                        for (int j = 20000; j < 20200; j++) {
                                            if (j == ((IPEndPoint)InfoSocket.LocalEndPoint).Port) {
                                                continue;
                                            }

                                            try {
                                                EndPoint point2 = new IPEndPoint(IPAddress.Parse(ado.GetUserById(friendId).Ip), j);

                                                InfoSocket.SendTo(Encoding.UTF8.GetBytes(user.Id + "同意了您的好友请求！"), point2);
                                            } catch { }
                                        }
                                    }

                                    if (result.ToString().Equals("Cancel")) {
                                        for (int j = 20000; j < 20200; j++) {

                                            if (j == ((IPEndPoint)InfoSocket.LocalEndPoint).Port) {
                                                continue;
                                            }

                                            try {
                                                EndPoint point2 = new IPEndPoint(IPAddress.Parse(ado.GetUserById(friendId).Ip), j);

                                                InfoSocket.SendTo(Encoding.UTF8.GetBytes(user.Id + "拒绝了您的好友请求！"), point2);
                                            } catch { }
                                        }

                                    }

                                    #endregion
                                }

                                

                                if (receiveString.Contains("拒绝了您的好友请求！")) {
                                    MessageBox.Show(receiveString);
                                }
                                if (receiveString.Contains("同意了您的好友请求！")) {
                                    MessageBox.Show(receiveString);

                                }

                                if (receiveString.Contains("请求通信")) {
                                    

                                    String friendId = receiveString.Replace("请求通信", "");
                                    User friend = ado.GetUserById(friendId);

                                    MessageBox.Show(friend.Name+"("+friendId+")"+"要和你联系了哦！");

                                    //Application.Run(new ChatForm(ServerSocket, friend));

                                }

                            }





                        } catch {

                        }

                    }

                }

            } catch (Exception e) {

                MessageBox.Show(e.Message);
                MessageBox.Show(e.GetType().ToString());
                MessageBox.Show(e.StackTrace);
            }
        }

        private void FriendsTreeView_AfterSelect(object sender, TreeViewEventArgs e) {

        }
    }
}
