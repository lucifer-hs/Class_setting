﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    public partial class ModifyInfoForm : Form {
        Ado ado = new Ado();
        public ModifyInfoForm(User user) {
            InitializeComponent();
            this.MaximizeBox = false;
            IdLabel.Text=user.Id;
            textBox1.Text = user.Password;
            textBox2.Text = user.Password;
            textBox3.Text = user.Name;
            textBox4.Text = user.PhoneNum;
            textBox5.Text = user.Email;
            textBox6.Text = user.Occupation;
            textBox7.Text = user.OtherInfo;
        }

        
        private void ModifyButton_Click(object sender, EventArgs e) {
            if (textBox1.Text.Equals("")) {
                MessageBox.Show("您还没有输入您的密码！");
                return;
            }
            if (!textBox1.Text.Equals(textBox2.Text)) {
                MessageBox.Show("两次输入的密码不一致，请检查您的密码重新输入");
                textBox1.Text = "";
                textBox2.Text = "";
                return;
            }

            User user = new User();
            user.Id = IdLabel.Text;
            user.Password = textBox1.Text;

            user.Name = textBox3.Text;
            user.PhoneNum = textBox4.Text;
            user.Email = textBox5.Text;
            user.Occupation = textBox6.Text;
            user.OtherInfo = textBox7.Text;
            ado.DeleteUserById(user.Id);
            ado.InsertUser(user);
            MessageBox.Show("更改成功，您需要重新启动溜溜！");
            this.Hide();
            Environment.Exit(0);
            
        }
    }
}
