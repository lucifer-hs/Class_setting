﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    public partial class SignUpForm : Form {
        Ado ado = new Ado();
        public SignUpForm() {
            InitializeComponent();
            this.MaximizeBox = false;
        }

        private void SignUpButton_Click(object sender, EventArgs e) {
            if (textBox1.Text.Equals("")) {
                MessageBox.Show("您还没有输入您的密码！");
                return;
            }
            if (!textBox1.Text.Equals(textBox2.Text)) {
                MessageBox.Show("两次输入的密码不一致，请检查您的密码重新输入");
                textBox1.Text = "";
                textBox2.Text = "";
                return;
            }
            User user = new User();
            user.Id = ado.GenerateId();
            user.Password = textBox1.Text;
            user.Name = textBox3.Text;
            user.PhoneNum = textBox4.Text;
            user.Email = textBox5.Text;
            user.Occupation = textBox6.Text;
            user.OtherInfo = textBox7.Text;
            ado.InsertUser(user);
            
            IdLabel.Text = "您的溜溜号为：" + user.Id;
            MessageBox.Show("恭喜您，注册成功，请记住您的溜溜帐号密码！");
            SignUpButton.Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e) {

        }

        private void textBox2_TextChanged(object sender, EventArgs e) {

        }

        private void textBox3_TextChanged(object sender, EventArgs e) {

        }

        private void textBox4_TextChanged(object sender, EventArgs e) {

        }

        private void textBox5_TextChanged(object sender, EventArgs e) {

        }

        private void textBox6_TextChanged(object sender, EventArgs e) {

        }

        private void textBox7_TextChanged(object sender, EventArgs e) {

        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void label3_Click(object sender, EventArgs e) {

        }

        private void label4_Click(object sender, EventArgs e) {

        }

        private void label5_Click(object sender, EventArgs e) {

        }

        private void label6_Click(object sender, EventArgs e) {

        }

        private void label7_Click(object sender, EventArgs e) {

        }

        private void IdLabel_Click(object sender, EventArgs e) {

        }
    }
}
