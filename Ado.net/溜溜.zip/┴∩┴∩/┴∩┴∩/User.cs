﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 溜溜 {
    public class User {
        private String id;
        private String password;
        private String ip;
        private String port;
        private String name;
        private String phoneNum;
        private String email;
        private String occupation;
        private String otherInfo;
        public User() {

        }
        public string Id {
            get {
                return id;
            }

            set {
                id = value;
            }
        }

        public string Password {
            get {
                return password;
            }

            set {
                password = value;
            }
        }

        public string Ip {
            get {
                return ip;
            }

            set {
                ip = value;
            }
        }

        public string Port {
            get {
                return port;
            }

            set {
                port = value;
            }
        }

        public string Name {
            get {
                return name;
            }

            set {
                name = value;
            }
        }

        public string PhoneNum {
            get {
                return phoneNum;
            }

            set {
                phoneNum = value;
            }
        }

        public string Email {
            get {
                return email;
            }

            set {
                email = value;
            }
        }

        public string Occupation {
            get {
                return occupation;
            }

            set {
                occupation = value;
            }
        }

        public string OtherInfo {
            get {
                return otherInfo;
            }

            set {
                otherInfo = value;
            }
        }
        public override string ToString() {
            return
                "id : " + this.id + "\n"
                + "ip : " + this.ip + "\n"
                + "port : " + this.port + "\n"
                + "name : " + this.name + "\n"
                + "phoneNum : " + this.phoneNum + "\n"
                + "email : " + this.email + "\n"
                + "occupation : " + this.occupation + "\n"                
                + "otherInfo : " + this.otherInfo + "\n";
        }

    }
}
