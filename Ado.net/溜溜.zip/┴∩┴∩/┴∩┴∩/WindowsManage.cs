﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 溜溜 {
    class WindowsManage {
        public static Form loginWindow = null;
        public static Form mainWindow = null;
        public static Form searchWindow = null;
        public static Form chatWindow = null;
    }
}
